function carregarProdutos(){

    let produtoSelecionado = ProdutoService.buscarProdutoSelecionado()

    document.getElementById("nome").innerHTML = produtoSelecionado.nome
    document.getElementById("descricao").innerHTML = produtoSelecionado.descricao
    document.getElementById("preco").innerHTML = produtoSelecionado.preco
    document.getElementById("imagem").src = produtoSelecionado.img
   
    document.getElementById("navbarTitle").innerHTML = produtoSelecionado.nome
}
function voltar(){
    history.go(-1)
}