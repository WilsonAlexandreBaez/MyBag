/**
 * 
 //chamar o buscar produtos da ProdutoService.
 */
 let produtosCadastrados = ProdutoService.buscarTodos()
 
function listarProdutos() {
/**
  produtos = [{'img':'https://s3.amazonaws.com/decora-platform-1-nv/2018/2/1/5a736b12e35ccc53019ba6cb.jpg','nome':'Sofá Lorem','descricao':'Teste','preco':'R$3.000,00'},{'img':'https://toqueacampainha.vteximg.com.br/arquivos/ids/1345164-530-530/107642_4.jpg?v=636391941963300000','nome':'Sofá Lorem 2','descricao':'Teste 2','preco':'R$3.200,00'}]
  localStorage.setItem('produtos', JSON.stringify(produtos));  
 */
    for (let i = 0; i < produtosCadastrados.length; i++) {
      const element = produtosCadastrados[i];
     
      //criar os cards de produtos no html
      
      document.getElementById('produtos').innerHTML += 
      /*html*/ `
      <div class="card-produto" onclick="selecionarProduto(${i})">
      <img src="${element.img}" alt="${element.nome}">
      <div class="card-produto-descricao">
          <h2>${element.nome}</h2>
          <p>${element.decricao}</p>
          <p>${element.preco}</p>
      </div>
      
      `
    }
 
}
function selecionarProduto(i){
  ProdutoService.selecionarProduto(produtosCadastrados[i])
  location.href = "produto.html"
}



