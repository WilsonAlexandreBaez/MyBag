class ProdutoService {
    /**
     * 
     */
    static validar(produto) {
        if (!produto.nome) {
            return "O nome é obrigatório."
        }
    }
    /**
     * buscara todos o produtos cadastrados 
     */

    static buscarTodos() {

        let produtos = JSON.parse(localStorage.getItem("produtos"))
        if (!produtos) return []
        else return produtos
    }
    //criando produto selecionando no local storang
    static selecionarProduto(produto){

        localStorage.setItem("produtoSelecionado", JSON.stringify(produto))
    }
    // buscar produto selecionado no local storange
    static buscarProdutoSelecionado(){
        return JSON.parse(localStorage.getItem("produtoSelecionado"))
    }

}