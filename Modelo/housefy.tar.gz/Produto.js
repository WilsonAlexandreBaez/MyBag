class {
    constructor(){
        this.nome = "";
        this.tamanho = "";
        this.cor = "";
        this.marca = "";

    }
    imprimirNome(){
        console.log(this.nome)
    }
    static imprimirOla(){
        console.log("Olá mundo!!")
    }
}